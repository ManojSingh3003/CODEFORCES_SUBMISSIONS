# Codeforces 1600 Rating Submissions

| # | Title | Solution | Tags | Submitted |
|:-:|-------|----------|------|-----------|
| 3 | [D - From 1 to Infinity](https://codeforces.com/contest/2132/problem/D) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2132/submission/335021524) | `binary search` `dp` `implementation` `math` `*1600` | Aug/22/2025 04:24 PM |
| 2 | [D - Stay or Mirror](https://codeforces.com/contest/2130/problem/D) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2130/submission/331891858) | `data structures` `greedy` `*1600` | Aug/01/2025 08:39 AM |
| 1 | [C - Game On Leaves](https://codeforces.com/contest/1363/problem/C) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/1363/submission/330326273) | `games` `trees` `*1600` | Jul/22/2025 08:17 PM |