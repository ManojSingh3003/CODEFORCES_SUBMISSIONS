# Codeforces 1500 Rating Submissions

| # | Title | Solution | Tags | Submitted |
|:-:|-------|----------|------|-----------|
| 2 | [C - Kefa and Park](https://codeforces.com/contest/580/problem/C) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/580/submission/329187558) | `dfs and similar` `graphs` `trees` `*1500` | Jul/16/2025 05:23 PM |
| 1 | [E - Sponsor of Your Problems](https://codeforces.com/contest/2121/problem/E) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2121/submission/325027315) | `dp` `greedy` `implementation` `strings` `*1500` | Jun/18/2025 06:07 PM |