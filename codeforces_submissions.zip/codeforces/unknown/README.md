# Codeforces unknown Rating Submissions

| # | Title | Solution | Tags | Submitted |
|:-:|-------|----------|------|-----------|
| 5 | [C - Against the Difference](https://codeforces.com/contest/2136/problem/C) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2136/submission/336128133) | `data structures` `dp` | Aug/29/2025 05:36 PM |
| 4 | [B - Like the Bitset](https://codeforces.com/contest/2136/problem/B) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2136/submission/336112949) | `constructive algorithms` `greedy` `two pointers` | Aug/29/2025 03:19 PM |
| 3 | [A - In the Dream](https://codeforces.com/contest/2136/problem/A) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2136/submission/336108668) | `greedy` `math` | Aug/29/2025 02:41 PM |
| 2 | [A - A + B Problem](https://codeforces.com/contest/105847/problem/A) | [C++17 (GCC 7-32)](https://codeforces.com/contest/105847/submission/322550649) |  | Jun/02/2025 08:33 PM |
| 1 | [A - Piecing It Together](https://codeforces.com/contest/2095/problem/A) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2095/submission/313507819) | `*special` `string suffix structures` | Apr/01/2025 10:19 PM |